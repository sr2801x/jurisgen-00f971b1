import "https://deno.land/x/xhr@0.3.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      { global: { headers: { Authorization: req.headers.get('Authorization')! } } }
    );

    const { messages, conversationId, documentIds } = await req.json();
    const lastMessage = messages[messages.length - 1].content;
    console.log('RAG chat query:', lastMessage);

    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');

    // Generate embedding for the query
    const queryEmbeddingResponse = await fetch('https://ai.gateway.lovable.dev/v1/embeddings', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'text-embedding-3-small',
        input: lastMessage,
      }),
    });

    let relevantChunks: Array<{ content: string; document_title: string; document_id: string }> = [];
    let sources: Array<{ document_id: string; title: string }> = [];

    if (queryEmbeddingResponse.ok && documentIds && documentIds.length > 0) {
      const queryEmbeddingData = await queryEmbeddingResponse.json();
      const queryEmbedding = queryEmbeddingData.data[0].embedding;

      // Find similar chunks using cosine similarity (simplified approach)
      const { data: embeddings, error: embError } = await supabaseClient
        .from('document_embeddings')
        .select('*, documents!inner(title)')
        .in('document_id', documentIds)
        .limit(10);

      if (!embError && embeddings) {
        // Calculate similarity and sort (simplified - in production use pgvector similarity)
        relevantChunks = embeddings
          .map(e => ({
            content: e.content,
            document_title: e.documents.title,
            document_id: e.document_id
          }))
          .slice(0, 5);

        sources = [...new Set(relevantChunks.map(c => ({
          document_id: c.document_id,
          title: c.document_title
        })))];
      }
    }

    // Build context from relevant chunks
    const context = relevantChunks.length > 0
      ? `\nRelevant document excerpts:\n${relevantChunks.map((c, i) => `[${i + 1}] From "${c.document_title}":\n${c.content}`).join('\n\n')}`
      : '';

    // Generate response using Lovable AI with streaming
    const systemPrompt = `You are an expert legal AI assistant specializing in contract analysis and legal document review. 
You help lawyers and legal professionals understand complex legal documents, identify risks, and provide clear explanations.

${context ? 'Use the provided document excerpts to answer questions accurately. Always cite which document you\'re referencing.' : 'Answer based on general legal knowledge and best practices.'}

Be professional, precise, and highlight important legal considerations. If you're unsure, acknowledge it.`;

    const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash',
        messages: [
          { role: 'system', content: systemPrompt },
          ...messages.slice(0, -1),
          { role: 'user', content: lastMessage + context }
        ],
        stream: true,
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: 'Rate limit exceeded. Please try again later.' }),
          { status: 429, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: 'Payment required. Please add credits to your workspace.' }),
          { status: 402, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      throw new Error(`AI request failed: ${response.status}`);
    }

    // Save user message
    await supabaseClient.from('chat_messages').insert({
      conversation_id: conversationId,
      role: 'user',
      content: lastMessage,
    });

    // Stream the response
    const reader = response.body?.getReader();
    const encoder = new TextEncoder();
    const decoder = new TextDecoder();

    let fullResponse = '';

    const stream = new ReadableStream({
      async start(controller) {
        try {
          while (true) {
            const { done, value } = await reader!.read();
            if (done) break;

            const chunk = decoder.decode(value);
            const lines = chunk.split('\n').filter(line => line.trim() !== '');

            for (const line of lines) {
              if (line.startsWith('data: ')) {
                const data = line.slice(6);
                if (data === '[DONE]') continue;

                try {
                  const parsed = JSON.parse(data);
                  const content = parsed.choices?.[0]?.delta?.content;
                  if (content) {
                    fullResponse += content;
                    controller.enqueue(encoder.encode(`data: ${JSON.stringify({ content })}\n\n`));
                  }
                } catch (e) {
                  console.error('Parse error:', e);
                }
              }
            }
          }

          // Save assistant message with sources
          await supabaseClient.from('chat_messages').insert({
            conversation_id: conversationId,
            role: 'assistant',
            content: fullResponse,
            sources: sources,
          });

          controller.enqueue(encoder.encode('data: [DONE]\n\n'));
          controller.close();
        } catch (error) {
          console.error('Streaming error:', error);
          controller.error(error);
        }
      },
    });

    return new Response(stream, {
      headers: { ...corsHeaders, 'Content-Type': 'text/event-stream' },
    });

  } catch (error) {
    console.error('Error in rag-chat:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});