import "https://deno.land/x/xhr@0.3.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      { global: { headers: { Authorization: req.headers.get('Authorization')! } } }
    );

    const { documentId } = await req.json();
    console.log('Analyzing document:', documentId);

    // Get document details
    const { data: document, error: docError } = await supabaseClient
      .from('documents')
      .select('*')
      .eq('id', documentId)
      .single();

    if (docError || !document) {
      throw new Error('Document not found');
    }

    // Update document status to processing
    await supabaseClient
      .from('documents')
      .update({ status: 'processing' })
      .eq('id', documentId);

    // Download document from storage
    const { data: fileData, error: downloadError } = await supabaseClient
      .storage
      .from('legal-documents')
      .download(document.file_path);

    if (downloadError || !fileData) {
      throw new Error('Failed to download document');
    }

    // Convert blob to text (simplified - in production use proper PDF parsing)
    const text = await fileData.text();
    console.log('Document text extracted, length:', text.length);

    // Use Lovable AI to analyze the document
    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
    
    const analysisPrompt = `You are a legal document analyzer. Analyze this legal document and provide:
1. A risk score from 0-100 (0 = no risk, 100 = high risk)
2. Risk level (low, medium, high, critical)
3. List of key legal terms found (max 15 terms)
4. A comprehensive summary (3-5 paragraphs)
5. Key clauses that need attention (list with explanations)
6. Potential legal issues or concerns (list with severity)

Document content:
${text.substring(0, 50000)}

Respond in JSON format:
{
  "riskScore": number,
  "riskLevel": "low" | "medium" | "high" | "critical",
  "keyTerms": [{"term": "string", "definition": "string"}],
  "summary": "string",
  "keyClauses": [{"clause": "string", "explanation": "string", "importance": "high" | "medium" | "low"}],
  "potentialIssues": [{"issue": "string", "severity": "critical" | "high" | "medium" | "low", "explanation": "string"}]
}`;

    const aiResponse = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash',
        messages: [
          { role: 'system', content: 'You are an expert legal document analyzer. Always respond with valid JSON.' },
          { role: 'user', content: analysisPrompt }
        ],
        response_format: { type: "json_object" }
      }),
    });

    if (!aiResponse.ok) {
      const errorText = await aiResponse.text();
      console.error('AI analysis error:', aiResponse.status, errorText);
      throw new Error(`AI analysis failed: ${aiResponse.status}`);
    }

    const aiData = await aiResponse.json();
    const analysisResult = JSON.parse(aiData.choices[0].message.content);
    console.log('AI analysis completed:', analysisResult);

    // Store analysis in database
    const { error: analysisError } = await supabaseClient
      .from('document_analysis')
      .insert({
        document_id: documentId,
        risk_score: analysisResult.riskScore,
        risk_level: analysisResult.riskLevel,
        key_terms: analysisResult.keyTerms,
        summary: analysisResult.summary,
        key_clauses: analysisResult.keyClauses,
        potential_issues: analysisResult.potentialIssues,
      });

    if (analysisError) {
      throw new Error('Failed to store analysis: ' + analysisError.message);
    }

    // Generate embeddings for RAG
    console.log('Generating embeddings for RAG...');
    const chunkSize = 1000;
    const chunks = [];
    for (let i = 0; i < text.length; i += chunkSize) {
      chunks.push(text.substring(i, i + chunkSize));
    }

    // Generate embeddings using AI
    const embeddingsPromises = chunks.slice(0, 20).map(async (chunk, index) => {
      const embeddingResponse = await fetch('https://ai.gateway.lovable.dev/v1/embeddings', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${LOVABLE_API_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'text-embedding-3-small',
          input: chunk,
        }),
      });

      if (embeddingResponse.ok) {
        const embeddingData = await embeddingResponse.json();
        return {
          document_id: documentId,
          chunk_index: index,
          content: chunk,
          embedding: embeddingData.data[0].embedding,
          metadata: { length: chunk.length }
        };
      }
      return null;
    });

    const embeddings = (await Promise.all(embeddingsPromises)).filter(e => e !== null);
    
    if (embeddings.length > 0) {
      await supabaseClient
        .from('document_embeddings')
        .insert(embeddings);
      console.log(`Stored ${embeddings.length} embeddings`);
    }

    // Update document status to completed
    await supabaseClient
      .from('documents')
      .update({ status: 'completed' })
      .eq('id', documentId);

    return new Response(
      JSON.stringify({ 
        success: true, 
        analysis: analysisResult,
        embeddingsCount: embeddings.length
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in analyze-document:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});