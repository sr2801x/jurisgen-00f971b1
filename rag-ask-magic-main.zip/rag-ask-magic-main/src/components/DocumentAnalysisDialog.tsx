import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { AlertTriangle, FileText, Scale } from "lucide-react";

interface DocumentAnalysisDialogProps {
  documentId: string;
  open: boolean;
  onClose: () => void;
}

const DocumentAnalysisDialog = ({ documentId, open, onClose }: DocumentAnalysisDialogProps) => {
  const [analysis, setAnalysis] = useState<any>(null);
  const [document, setDocument] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (open && documentId) {
      loadAnalysis();
    }
  }, [open, documentId]);

  const loadAnalysis = async () => {
    try {
      const [docResult, analysisResult] = await Promise.all([
        supabase.from('documents').select('*').eq('id', documentId).single(),
        supabase.from('document_analysis').select('*').eq('document_id', documentId).single(),
      ]);

      if (docResult.data) setDocument(docResult.data);
      if (analysisResult.data) setAnalysis(analysisResult.data);
    } catch (error) {
      console.error("Failed to load analysis:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const getRiskColor = (riskLevel: string) => {
    switch (riskLevel) {
      case 'low': return 'bg-success text-success-foreground';
      case 'medium': return 'bg-warning text-warning-foreground';
      case 'high': return 'bg-destructive text-destructive-foreground';
      case 'critical': return 'bg-destructive text-destructive-foreground';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'low': return 'text-success';
      case 'medium': return 'text-warning';
      case 'high': return 'text-destructive';
      case 'critical': return 'text-destructive';
      default: return 'text-muted-foreground';
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <FileText className="w-5 h-5" />
            <span>{document?.title || "Document Analysis"}</span>
          </DialogTitle>
        </DialogHeader>

        {isLoading ? (
          <div className="py-8 text-center text-muted-foreground">Loading analysis...</div>
        ) : !analysis ? (
          <div className="py-8 text-center text-muted-foreground">No analysis available</div>
        ) : (
          <div className="space-y-6">
            {/* Risk Score Card */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span className="flex items-center space-x-2">
                    <Scale className="w-5 h-5" />
                    <span>Risk Assessment</span>
                  </span>
                  <Badge className={getRiskColor(analysis.risk_level)}>
                    {analysis.risk_score}/100 - {analysis.risk_level.toUpperCase()}
                  </Badge>
                </CardTitle>
              </CardHeader>
            </Card>

            {/* Summary */}
            <Card>
              <CardHeader>
                <CardTitle>Executive Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm leading-relaxed">{analysis.summary}</p>
              </CardContent>
            </Card>

            {/* Key Terms */}
            {analysis.key_terms && analysis.key_terms.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Key Legal Terms</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {analysis.key_terms.map((term: any, index: number) => (
                      <div key={index} className="space-y-1">
                        <h4 className="font-semibold text-sm">{term.term}</h4>
                        <p className="text-sm text-muted-foreground">{term.definition}</p>
                        {index < analysis.key_terms.length - 1 && <Separator className="mt-3" />}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Key Clauses */}
            {analysis.key_clauses && analysis.key_clauses.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Important Clauses</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {analysis.key_clauses.map((clause: any, index: number) => (
                      <div key={index} className="space-y-2">
                        <div className="flex items-start justify-between">
                          <h4 className="font-semibold text-sm">{clause.clause}</h4>
                          <Badge variant="outline">{clause.importance}</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">{clause.explanation}</p>
                        {index < analysis.key_clauses.length - 1 && <Separator className="mt-3" />}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Potential Issues */}
            {analysis.potential_issues && analysis.potential_issues.length > 0 && (
              <Card className="border-destructive/50">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2 text-destructive">
                    <AlertTriangle className="w-5 h-5" />
                    <span>Potential Issues & Risks</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {analysis.potential_issues.map((issue: any, index: number) => (
                      <div key={index} className="space-y-2">
                        <div className="flex items-start justify-between">
                          <h4 className={`font-semibold text-sm ${getSeverityColor(issue.severity)}`}>
                            {issue.issue}
                          </h4>
                          <Badge variant="outline" className={getSeverityColor(issue.severity)}>
                            {issue.severity}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">{issue.explanation}</p>
                        {index < analysis.potential_issues.length - 1 && <Separator className="mt-3" />}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};

export default DocumentAnalysisDialog;