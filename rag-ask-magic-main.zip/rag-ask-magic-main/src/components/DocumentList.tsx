import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { FileText, AlertTriangle, CheckCircle, Clock, Trash2 } from "lucide-react";
import { toast } from "sonner";
import DocumentAnalysisDialog from "./DocumentAnalysisDialog";

interface Document {
  id: string;
  title: string;
  status: string;
  created_at: string;
  document_analysis?: {
    risk_score: number;
    risk_level: string;
  }[];
}

interface DocumentListProps {
  onSelectDocuments: (ids: string[]) => void;
}

const DocumentList = ({ onSelectDocuments }: DocumentListProps) => {
  const [documents, setDocuments] = useState<Document[]>([]);
  const [selectedDocs, setSelectedDocs] = useState<Set<string>>(new Set());
  const [selectedDoc, setSelectedDoc] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadDocuments();
  }, []);

  const loadDocuments = async () => {
    try {
      const { data, error } = await supabase
        .from('documents')
        .select(`
          *,
          document_analysis(risk_score, risk_level)
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setDocuments(data || []);
    } catch (error: any) {
      toast.error("Failed to load documents");
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleToggleDoc = (docId: string) => {
    const newSelected = new Set(selectedDocs);
    if (newSelected.has(docId)) {
      newSelected.delete(docId);
    } else {
      newSelected.add(docId);
    }
    setSelectedDocs(newSelected);
    onSelectDocuments(Array.from(newSelected));
  };

  const handleDeleteDocument = async (docId: string) => {
    try {
      const { error } = await supabase
        .from('documents')
        .delete()
        .eq('id', docId);

      if (error) throw error;
      toast.success("Document deleted");
      loadDocuments();
    } catch (error: any) {
      toast.error("Failed to delete document");
      console.error(error);
    }
  };

  const getRiskColor = (riskLevel: string) => {
    switch (riskLevel) {
      case 'low': return 'bg-success text-success-foreground';
      case 'medium': return 'bg-warning text-warning-foreground';
      case 'high': return 'bg-destructive text-destructive-foreground';
      case 'critical': return 'bg-destructive text-destructive-foreground';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <CheckCircle className="w-4 h-4 text-success" />;
      case 'processing': return <Clock className="w-4 h-4 text-info animate-spin" />;
      case 'failed': return <AlertTriangle className="w-4 h-4 text-destructive" />;
      default: return <Clock className="w-4 h-4 text-muted-foreground" />;
    }
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="py-8 text-center text-muted-foreground">
          Loading documents...
        </CardContent>
      </Card>
    );
  }

  if (documents.length === 0) {
    return (
      <Card>
        <CardContent className="py-8 text-center text-muted-foreground">
          No documents uploaded yet. Upload your first document above!
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle>Your Documents</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {documents.map((doc) => {
            const analysis = doc.document_analysis?.[0];
            return (
              <div
                key={doc.id}
                className="flex items-center space-x-4 p-4 border rounded-lg hover:bg-muted/50 transition-colors"
              >
                <Checkbox
                  checked={selectedDocs.has(doc.id)}
                  onCheckedChange={() => handleToggleDoc(doc.id)}
                  disabled={doc.status !== 'completed'}
                />
                <FileText className="w-8 h-8 text-primary flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold truncate">{doc.title}</h3>
                  <div className="flex items-center space-x-2 mt-1">
                    {getStatusIcon(doc.status)}
                    <span className="text-sm text-muted-foreground capitalize">{doc.status}</span>
                    {analysis && (
                      <Badge className={getRiskColor(analysis.risk_level)}>
                        Risk: {analysis.risk_score}/100
                      </Badge>
                    )}
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  {doc.status === 'completed' && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setSelectedDoc(doc.id)}
                    >
                      View Analysis
                    </Button>
                  )}
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleDeleteDocument(doc.id)}
                  >
                    <Trash2 className="w-4 h-4 text-destructive" />
                  </Button>
                </div>
              </div>
            );
          })}
        </CardContent>
      </Card>

      {selectedDoc && (
        <DocumentAnalysisDialog
          documentId={selectedDoc}
          open={!!selectedDoc}
          onClose={() => setSelectedDoc(null)}
        />
      )}
    </>
  );
};

export default DocumentList;