import { useState, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Upload, FileText, Loader2 } from "lucide-react";
import { toast } from "sonner";

const DocumentUpload = () => {
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file type
    const allowedTypes = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
    if (!allowedTypes.includes(file.type)) {
      toast.error("Please upload a PDF or Word document");
      return;
    }

    // Validate file size (50MB max)
    if (file.size > 52428800) {
      toast.error("File size must be less than 50MB");
      return;
    }

    setIsUploading(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      // Upload file to storage
      const filePath = `${user.id}/${Date.now()}-${file.name}`;
      const { error: uploadError } = await supabase.storage
        .from('legal-documents')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      // Create document record
      const { data: document, error: docError } = await supabase
        .from('documents')
        .insert({
          user_id: user.id,
          title: file.name,
          file_path: filePath,
          file_size: file.size,
          mime_type: file.type,
          status: 'pending',
        })
        .select()
        .single();

      if (docError) throw docError;

      toast.success("Document uploaded! Analysis in progress...");

      // Trigger document analysis
      const { error: analysisError } = await supabase.functions.invoke('analyze-document', {
        body: { documentId: document.id }
      });

      if (analysisError) {
        console.error("Analysis error:", analysisError);
        toast.error("Document uploaded but analysis failed. Please try again.");
      } else {
        toast.success("Document analysis completed!");
      }

      // Reset file input
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }

      // Reload page to show new document
      window.location.reload();

    } catch (error: any) {
      console.error("Upload error:", error);
      toast.error(error.message || "Failed to upload document");
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Upload className="w-5 h-5" />
          <span>Upload Legal Document</span>
        </CardTitle>
        <CardDescription>
          Upload contracts, agreements, or legal documents for AI-powered analysis
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="border-2 border-dashed border-border rounded-lg p-8 text-center hover:border-primary transition-colors">
          <input
            ref={fileInputRef}
            type="file"
            accept=".pdf,.doc,.docx"
            onChange={handleFileUpload}
            disabled={isUploading}
            className="hidden"
            id="file-upload"
          />
          <label
            htmlFor="file-upload"
            className="cursor-pointer flex flex-col items-center space-y-4"
          >
            {isUploading ? (
              <>
                <Loader2 className="w-12 h-12 text-primary animate-spin" />
                <div className="space-y-2">
                  <p className="text-lg font-semibold">Uploading & Analyzing...</p>
                  <p className="text-sm text-muted-foreground">This may take a moment</p>
                </div>
              </>
            ) : (
              <>
                <FileText className="w-12 h-12 text-muted-foreground" />
                <div className="space-y-2">
                  <p className="text-lg font-semibold">Click to upload document</p>
                  <p className="text-sm text-muted-foreground">PDF or Word (max 50MB)</p>
                </div>
                <Button type="button" variant="outline">
                  Choose File
                </Button>
              </>
            )}
          </label>
        </div>
      </CardContent>
    </Card>
  );
};

export default DocumentUpload;