import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { Scale, FileText, MessageSquare, Shield } from "lucide-react";

const Index = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/30">
      {/* Hero Section */}
      <div className="container mx-auto px-4 py-16">
        <div className="text-center space-y-6 max-w-4xl mx-auto">
          <div className="flex justify-center mb-6">
            <div className="w-20 h-20 rounded-2xl bg-primary flex items-center justify-center shadow-lg">
              <Scale className="w-10 h-10 text-primary-foreground" />
            </div>
          </div>
          
          <h1 className="text-5xl md:text-6xl font-bold tracking-tight">
            LegalAI Analyzer
          </h1>
          
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            AI-powered legal document analysis with advanced risk assessment and RAG-based intelligent chat
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center pt-8">
            <Button size="lg" onClick={() => navigate("/auth")}>
              Get Started
            </Button>
            <Button size="lg" variant="outline" onClick={() => navigate("/auth")}>
              Sign In
            </Button>
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-3 gap-8 mt-20">
          <div className="text-center space-y-4 p-6 rounded-lg border bg-card">
            <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mx-auto">
              <FileText className="w-6 h-6 text-primary" />
            </div>
            <h3 className="text-xl font-semibold">Document Analysis</h3>
            <p className="text-muted-foreground">
              Upload contracts and legal documents for comprehensive AI-powered analysis with risk scoring
            </p>
          </div>

          <div className="text-center space-y-4 p-6 rounded-lg border bg-card">
            <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mx-auto">
              <Shield className="w-6 h-6 text-primary" />
            </div>
            <h3 className="text-xl font-semibold">Risk Assessment</h3>
            <p className="text-muted-foreground">
              Identify potential issues, key terms, and critical clauses with AI-driven risk evaluation
            </p>
          </div>

          <div className="text-center space-y-4 p-6 rounded-lg border bg-card">
            <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mx-auto">
              <MessageSquare className="w-6 h-6 text-primary" />
            </div>
            <h3 className="text-xl font-semibold">RAG Chat</h3>
            <p className="text-muted-foreground">
              Ask questions about your documents with context-aware AI responses powered by retrieval-augmented generation
            </p>
          </div>
        </div>

        {/* Tech Stack */}
        <div className="mt-20 text-center space-y-6">
          <h2 className="text-2xl font-semibold">Built for Legal Professionals</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Powered by advanced AI models including Google Gemini 2.5 Flash with secure authentication, 
            vector embeddings for semantic search, and intelligent document processing
          </p>
        </div>
      </div>

      {/* Footer */}
      <div className="border-t mt-20">
        <div className="container mx-auto px-4 py-8 text-center text-sm text-muted-foreground">
          <p>© 2025 LegalAI Analyzer. Built with Lovable Cloud & Lovable AI.</p>
        </div>
      </div>
    </div>
  );
};

export default Index;
